#include "DxLib.h"
#include <math.h>
#include "ijou_header.h"

double AngToRad(double ang) {
	return -(ang / 180.0)*PI;
}
double rate(double current, double max) {
	return (current / max) * 100;
}
double RadToAng(double rad) {
	return -(rad*180.0) / PI;
}
double SecToFrame(double Sec) {
	return Sec * 60;
}
double aPers(double apers){
	return apers / SecToFrame(1.0);
}
double offsetX(double r, double ang) {
	return r * cos(AngToRad(ang));
}
double offsetY(double r, double ang) {
	return r * sin(AngToRad(ang));
}
int DrawGraph2(int x, int y, int gh, int TransFlag) {//��1,2���������S���W�ɂȂ���DrawGraph�֐�
	int width, height;

	GetGraphSize(gh, &width, &height);
	DrawGraph(x - width / 2, y - height / 2, gh, TransFlag);

	return 1;
}
void DrawBox2(double x, double y, double w, double h, int color) {//��1,2���������S���W,3,4�͕��A�����A�Ō�ɐF�B

	DrawBox(x - w / 2, y - h / 2, x + w / 2, y + h / 2, color, 1);

}
int isCollCirWithCir(double x1, double y1, double r1, double x2, double y2, double r2) {
	if (r1 + r2 > hypot(x2 - x1, y2 - y1))
		return 1;
	else
		return 0;
}
double S_Triangle(double a, double b, double c) {//�w�����̌�����p���āA�O�ӂ��炻�̎O�p�`�̖ʐς��Z�o
	double s = (a + b + c) / 2;
	return sqrt(s*(s - a)*(s - b)*(s - c));
}
void createPolygonShot01(double k, double n, double x, double y, double ang, double v, int graph, int color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i, j; double ang_0 = ang;
	for (i = 0; i < k; i++) {
		for (j = ang - 180 / k; j <= ang + 180 / k; j += 360 / (n*k)) {
			createshot05(x, y, j, ang_0 + (360 / k) * i, v, graph, color, damage, ijou_damage, ijou_type, delay);
		}
		ang += 360 / k;
	}
}
void createPolygonShot02(double k, double n, double x, double y, double ang,double ang_a, double v,double a, int graph, int color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i, j; double ang_0 = ang;
	for (i = 0; i < k; i++) {
		for (j = ang - 180 / k; j <= ang + 180 / k; j += 360 / (n*k)) {
			createshot05(x, y, j, ang_a, ang_0 + (360 / k) * i, v, a, graph, color, damage, ijou_damage, ijou_type, delay);
		}
		ang += 360 / k;
	}
}
void createPolygonShot02(double k, double n, double x, double y, double ang, double v, double a, int graph, int color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i, j; double ang_0 = ang;
	for (i = 0; i < k; i++) {
		for (j = ang - 180 / k; j <= ang + 180 / k; j += 360 / (n*k)) {
			createshot05(x, y, j, j, ang_0 + (360 / k) * i, v, a, graph, color, damage, ijou_damage, ijou_type, delay);
		}
		ang += 360 / k;
	}
}
void createPolygonShot03(double k,double n,double x,double y,double ang,double v,double mo,double mo_a,double mo_e ,int graph, int color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i, j; double ang_0 = ang;
	for (i = 0; i < k; i++) {
		for (j = ang - 180 / k; j <= ang + 180 / k; j += 360 / (n*k)) {
			createshot05(x, y, j,0, ang_0 + (360 / k) * i, v,0,mo,mo_a,mo_e ,graph, color, damage, ijou_damage, ijou_type, delay);
		}
		ang += 360 / k;
	}
}
int is_create01(int interval) {
	if (sys.count_stg%interval == 0)
		return 1;
	else
		return 0;
}
int is_create02(int time_s, int time_e, int interval) {
	if (sys.count_stg>=time_s && sys.count_stg<time_e && sys.count_stg%interval == 0)
		return 1;
	else
		return 0;
}
int is_create03(int interval,int devide,int interval_m) {
	int i = interval / devide, j;
	for (j = interval / devide; j <= interval; j += i) {
		if (sys.count_stg%interval <= j && sys.count_stg%interval >= j - i && sys.count_stg%interval_m ==1 )
			return j / i;
	}
		return 0;
}