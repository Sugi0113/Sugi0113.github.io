#include "DxLib.h"
#include <math.h>
int CurrentShot_E[2] = {}, CurrentShot_P = 0;
int debug = -1;
#include "ijou_header.h"
#include "Sugi.h"
//#include <time.h>
unsigned long long int time_prev = 0, fps = 0;
#define MaxShot_P 1000
#define Max_Enemy 300
#define Max_Particle 10000
E_Shot shot_e[MaxShot_E];
E_Shot shot_e_add[MaxShot_E];
E_Shot shot_p[MaxShot_P];
Particle particle[Max_Particle];
Zako zako[Max_Enemy];
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
	ChangeWindowMode(TRUE), DxLib_Init(), SetDrawScreen(DX_SCREEN_BACK); //�E�B���h�E���[�h�ύX�Ə������Ɨ���ʐݒ�
	//SetWindowSizeExtendRate(2, 2);
	init_title();

	while (ScreenFlip() == 0 && ProcessMessage() == 0 && ClearDrawScreen() == 0) {
		switch (sys.stage) {
		case 0://title
			break;
		case 1://stage1+
			if (sys.count_stg == 1)
				init_stg1();
			if (is_create03(42, 2, 3) != 0) {
				static int id = 1; static double ang = 0;
				if (is_create03(84, 2, 6) == 1) {
					createPolygonShot01(6, 3, GetCX_f, GetCY_f, ang, 1, 5, id, 0, 0, 2, 0);
					if (++id == 8)
						id = 1;
					ang += 2;
				}
				if (is_create03(84, 2, 6) == 2) {
					createPolygonShot01(6, 3, GetCX_f, GetCY_f, ang, 1, 5, id, 0, 0, 2, 0);
					id++;
					if (id == 8)
						id = 1;
					ang -= 3;
				}
			}
			//�ʃo�[�W�����̒e
			/*if (sys.pose == 0)
				stg1();*/
			/*
			if (sys.count_stg == 1)
				init_stg1();
			if (is_create01(15) == 1) {
				static double ang = 0;
				for (int i = 0; i < 5; i++) {

					createshot1234(GetCX_f, GetCY_f, ang, ang-90, 2, 0, -5, aPers(1.6), 360*5, 900, 4, 0, 2, 0, 0, 10);
					ang += 360 / 5;
				}
				ang += 3.7;
			}
			stg1();
			*/
			break;
		case 3://stage3
			break;
		case 4:
			break;
		}
		gpCalc(), gpDraw();
		if (sys.pose == 0)
			sys.count_stg++;
		
		sys.count_all++;
		clsDx();
/*
		if (sys.count_all % 50 == 0) {
			unsigned long long int t = clock();
			fps = 50 * CLOCKS_PER_SEC / (t - time_prev);
			time_prev = t;
		}
*/
		//�����Ƀf�o�b�O���b�Z�[�W��
		//printfDx("%d,%d", debug,CurrentShot_E[0]);
	}
	DxLib_End();// DX���C�u�����I������
	return 0;
}

void gpCalc() {
	static int time = 0;
	switch (sys.stage) {
		int i;
	case 0:
		title.calc();
		break;
	case 1:
		if (sys.pose == 0) {
			player.move();
			UI_r.calc();
			for (int max = CurrentShot_P, lop = 0, i = -1; lop < max; lop++) {
				while (!shot_p[++i].exist);
				if (shot_p[i].standby == 0 && shot_p[i].delay == 0) {
					int j;
					for (j = 0; j < Max_Enemy; j++) {
						if (isCollCirWithCir(shot_p[i].x, shot_p[i].y, shot_p[i].r, zako[j].x, zako[j].y, zako[j].r) == 1 && zako[j].standby == 0) {
							zako[j].hp -= shot_p[i].damage;
							shot_p[i].vanish_p(10);
						}
					}
					shot_p[i].move_p();
				}
			}
			//bottom[0](��add�e�pbottom)����X�^�[�g�Alop�͉񐔂𐔂��邾���A���[�v�J�n����CurrentShot_E�ɒB����܂ŉ�
			for (int lop = 0, j = bottom[0], max = CurrentShot_E[0]; lop < max; lop++) {
				//-1�͕Ԃ��ė��Ȃ��͂������ǔO�̂���
				if (j == -1)
					break;
				//j���瑀��Ώ�i�𓾂�
				int i = draw_rank_e[j].value;
				if (shot_e[i].standby == 0) {
					if (shot_e[i].delay == 0) {
						if (isCollCirWithCir(shot_e[i].x, shot_e[i].y, shot_e[i].r, player.x, player.y, player.r) == 1 && player.invincible == 0) {
							if (shot_e[i].damage != 0) {
								if (player.shield == 0)
									hidan();
								else {
									player.shield_add(-shot_e[i].damage);
									PlaySoundMem(se.shield_damage, 1);
									if (player.shield == 0) {
										player.set_invincible(120);
										PlaySoundMem(se.shield_break, 1);
									}
								}
							}
							else
								PlaySoundMem(se.shield_damage, 1);
							if (shot_e[i].ijou_type != 0 && player.is_ijou[shot_e[i].ijou_type - 1] == 0) {
								player.ijou_param_add(shot_e[i].ijou_type - 1, shot_e[i].ijou_damage);
							}
							shot_e[i].vanish_e(30, j, false);
						}
						if (isCollCirWithCir(shot_e[i].x, shot_e[i].y, shot_e[i].r, player.x, player.y, player.r + 5) == 1 && shot_e[i].is_graze == 0) {
							PlaySoundMem(se.graze, 1);
							shot_e[i].is_graze = 1;
						}
					}
					shot_e[i].move_e(j, false);
				}
				//j�̒l�����̗v�f�Ɉڂ�
				j = draw_rank_e[j].next;
			}

			for (int lop = 0, j = bottom[1], max = CurrentShot_E[1]; lop < max; lop++) {
				if (j == -1)
					break;
				int i = draw_rank_e[j].value;
				if (shot_e_add[i].standby == 0) {
					if (shot_e_add[i].delay == 0) {
						if (isCollCirWithCir(shot_e_add[i].x, shot_e_add[i].y, shot_e_add[i].r, player.x, player.y, player.r) == 1 && player.invincible == 0) {
							if (shot_e_add[i].damage != 0) {
								if (player.shield == 0)
									hidan();
								else {
									player.shield_add(-shot_e_add[i].damage);
									PlaySoundMem(se.shield_damage, 1);
									if (player.shield == 0) {
										player.set_invincible(120);
										PlaySoundMem(se.shield_break, 1);
									}
								}
							}
							else
								PlaySoundMem(se.shield_damage, 1);
							if (shot_e_add[i].ijou_type != 0 && player.is_ijou[shot_e_add[i].ijou_type - 1] == 0) {
								player.ijou_param_add(shot_e_add[i].ijou_type - 1, shot_e_add[i].ijou_damage);
							}
						}
						if (isCollCirWithCir(shot_e_add[i].x, shot_e_add[i].y, shot_e_add[i].r, player.x, player.y, player.r + 5) == 1 && shot_e_add[i].is_graze == 0) {
							PlaySoundMem(se.graze, 1);
							shot_e_add[i].is_graze = 1;
						}
					}
					shot_e_add[i].move_e(j, true);
				}
				j = draw_rank_e[j].next;
			}
			for (i = 0; i < Max_Enemy; i++) {
				if (zako[i].standby == 0)
					zako[i].move();
			}
			for (i = 0; i < Max_Particle; i++) {
				if (particle[i].standby == 0 && particle[i].delay == 0) {
					particle[i].move();
				}
			}
		}
		else
			pose.calc();

		if (CheckHitKey(KEY_INPUT_ESCAPE)) {
			if (time == 0) {
				if (sys.pose == 0)
					sys.pose = 1;
				else
					sys.pose = 0;
			}
			time++;
		}
		else
			time = 0;
		break;
	case 2:
		break;
	case 3:
		break;
	case 4:
		break;
	}
	if (player.is_hidan) {
		for (int lop = 0, j = bottom[0], max = CurrentShot_E[0]; lop < max; lop++) {
			if (j == -1)
				break;
			int i = draw_rank_e[j].value;
			if (shot_e[i].standby == 0) {
				shot_e[i].vanish_e(60, j,false);
			}
			j = draw_rank_e[j].next;
		}
		for (int lop = 0, j = bottom[1], max = CurrentShot_E[1]; lop < max; lop++) {
			if (j == -1)
				break;
			int i = draw_rank_e[j].value;
			if (shot_e_add[i].standby == 0) {
				shot_e_add[i].vanish_e(60, j,true);
			}
			j = draw_rank_e[j].next;
		}
	}
}

void gpDraw() {
	int i;
	switch (sys.stage) {
	case 0:
		title.draw();
		break;
	case 1:
		for (i = 0; i < Max_Particle; i++) {
			if (particle[i].exist) {
				particle[i].draw();
			}
		}
		for (i = 0; i < Max_Enemy; i++) {
			if (zako[i].exist)
				zako[i].draw();
		}
		player.draw();
		for (int i = bottom[0], lop = 0; lop < CurrentShot_E[0]; lop++, i = draw_rank_e[i].next) {
			int j = draw_rank_e[i].value;
			if (shot_e[j].exist &&shot_e[j].delay == 0)
				shot_e[j].draw();
		}
		for (int i = 0, j = -1; i < CurrentShot_P; i++) {
			while (!shot_p[++j].exist);
			shot_p[j].draw();
		}
		SetDrawBlendMode(DX_BLENDMODE_ADD, 255);
		for (int i = bottom[1], lop = 0; lop < CurrentShot_E[1]; lop++, i = draw_rank_e[i].next) {
			int j = draw_rank_e[i].value;
			if (shot_e_add[j].exist &&shot_e_add[j].delay == 0)
				shot_e_add[j].draw();
		}
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 10);
		DrawGraph2(GetCX, GetCY, stg.frame, 1);
		if (sys.pose == 1)
			pose.draw();
		UI_r.draw();

		break;
	case 2:
		DrawGraph2(GetCX, GetCY, stg.frame, 1);
		break;
	case 3:
		DrawGraph2(GetCX, GetCY, stg.frame, 1);
		break;
	case 4:
		DrawGraph2(GetCX, GetCY, stg.frame, 1);
		break;
	}
}

void init_title() {
	sys.stage = 0;
	sys.count_stg = 0;
	title.choice = 0, title.choice2 = 0;
	title.graph[0] = LoadGraph("graphic/title/ijou_title.png", 1);
	title.graph[1] = LoadGraph("graphic/title/title_start.png", 1);
	title.graph[2] = LoadGraph("graphic/title/title_quit.png", 1);
	title.graph[3] = LoadGraph("graphic/title/diffic.png", 1);
	title.graph[4] = LoadGraph("graphic/title/diffic_easy.png", 1);
	title.graph[5] = LoadGraph("graphic/title/diffic_normal.png", 1);
	title.graph[6] = LoadGraph("graphic/title/diffic_hard.png", 1);
	title.graph[7] = LoadGraph("graphic/title/diffic_lunatic.png", 1);
	title.graph[8] = LoadGraph("graphic/title/player.png", 1);
	title.graph[9] = LoadGraph("graphic/title/player_boy.png", 1);
	title.graph[10] = LoadGraph("graphic/title/player_girl.png", 1);
	se.init();
	bgm.stg[0] = LoadSoundMem("music/title.wma");
	PlaySoundMem(bgm.stg[0], 1);
}
void init_stg1() {
	stg.frame = LoadGraph("graphic/title/ijou_frame.png");
	StopSoundMem(bgm.stg[0]);
	LoadDivGraph("graphic/bullet.png", 10, 10, 1, 30, 30, s_typ.graph);
	LoadDivGraph("graphic/ijou_ico.png", 8, 8, 1, 50, 50, UI_r.ico);

	UI_r.text[0] = LoadGraph("graphic/hp.png", 1);
	UI_r.text[1] = LoadGraph("graphic/bom.png", 1);
	UI_r.text[2] = LoadGraph("graphic/ijou.png", 1);
	player.init();
}

void stg1() {
	static int prm = 0;
	if (is_create02(60,300,60)==1) {
		createEnemy01(GetCX_f - 170 + prm, GetmY_f - 100 - prm, 10, 0);
		createEnemy01(GetCX_f + 170 - prm, GetmY_f - 100 - prm, 10, 0);
		prm += 20;
	}
	if (is_create02(300, 600, 30) == 1) {
		createEnemy01(GetCX_f - 170 + prm, GetmY_f - 100 - prm, 10, 0);
		createEnemy01(GetCX_f + 170 - prm, GetmY_f - 100 - prm, 10, 0);
		prm -= 10;
	}
	if (is_create02(1200, 1500, 60) == 1) {
		createEnemy01(GetCX_f - 170 + prm, GetmY_f - 50, 10, 1);
		createEnemy01(GetCX_f + 170 - prm, GetmY_f - 50, 10, 1);
		prm += 20;
	}
	if (is_create02(1500,1600,20) == 1) {
		createEnemy01(GetCX_f - 170 + prm, GetmY_f - 50, 10, 1);
		createEnemy01(GetCX_f + 170 - prm, GetmY_f - 50, 10, 1);
		
	}
}
void hidan() {
	PlaySoundMem(se.hidan, 1);
	player.set_invincible(160);
	sys.is_PlayerKey = 0;
	player.is_hidan = 1;
	player.hp_add(-1);
	player.shield_add(100);
	rupture01(player.x, player.y, 300, 0, 20);
}
void createshot01(double x, double y, double ang, double v, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E; i++) {
		if (shot_e[i].standby) {
			p_i[0] = 0, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[4] = v, p_d[10] = damage, p_d[13] = ijou_damage;
			shot_e[i].init(p_i, p_d);
			push(i, false);
			break;
		}
	}
}
void createshot01_p(double x, double y, double ang, double v, int id_graph, int id_color, double damage, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_P; i++) {
		if (shot_p[i].standby) {
			p_i[0] = 0, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[8] = 0;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[4] = v, p_d[10] = damage;
			shot_p[i].init(p_i, p_d);
			CurrentShot_P++;
			break;
		}
	}
}
void createshot02(double x, double y, double ang, double v, double a, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E; i++) {
		if (shot_e[i].standby) {
			p_i[0] = 1, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[3] = ang, p_d[4] = v, p_d[5] = a, p_d[10] = damage, p_d[13] = ijou_damage;
			shot_e[i].init(p_i, p_d);
			push(i, false);
			break;
		}
	}
}
void createshot02(double x, double y, double ang, double ang_a, double v, double a,  int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E; i++) {
		if (shot_e[i].standby) {
			p_i[0] = 1, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[3] = ang_a, p_d[4] = v, p_d[5] = a, p_d[10] = damage, p_d[13] = ijou_damage;
			shot_e[i].init(p_i, p_d);
			break;
		}
	}
}
void createshot03(double x, double y, double ang, double v, double mo, double mo_e, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E; i++) {
		if (shot_e[i].standby) {
			p_i[0] = 2, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[4] = v, p_d[7] = mo, p_d[8] = mo_e, p_d[10] = damage, p_d[13] = ijou_damage, p_d[14] = 0;
			shot_e[i].init(p_i, p_d);
			break;
		}
	}
}
void createshot03(double x, double y, double ang, double v, double mo,double mo_a, double mo_e, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E; i++) {
		if (shot_e[i].standby) {
			p_i[0] = 2, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[4] = v, p_d[7] = mo, p_d[8] = mo_e, p_d[10] = damage, p_d[13] = ijou_damage, p_d[14] = mo_a;
			shot_e[i].init(p_i, p_d);
			push(i, false);
			break;
		}
	}
}
void createshot04(double x, double y, double ang, double v, int time, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E; i++) {
		if (shot_e[i].standby) {
			p_i[0] = 3, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[6] = time, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[4] = v, p_d[10] = damage, p_d[13] = ijou_damage;
			shot_e[i].init(p_i, p_d);
			push(i, false);
			break;
		}
	}
}
void createshot04_add(double x, double y, double ang, double v, int time, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E; i++) {
		if (shot_e_add[i].standby) {
			p_i[0] = 3, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[6] = time, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang,p_d[4] = v, p_d[10] = damage, p_d[13] = ijou_damage;
			shot_e_add[i].init(p_i, p_d);
			push(i, true);
			break;
		}
	}
}
void createshot1234(double x, double y, double ang,double ang_a ,double v,double a, double mo, double mo_a, double mo_e,int time, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E; i++) {
		if (shot_e[i].standby) {
			p_i[0] = 5, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[6] = time, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[5] = ang_a, p_d[4] = v, p_d[5] = a, p_d[7] = mo, p_d[8] = mo_e, p_d[10] = damage, p_d[13] = ijou_damage, p_d[14] = mo_a;
			shot_e[i].init(p_i, p_d);
			push(i, false);
			break;
		}
	}
}
void createshot05(double x, double y, double ang, double ang_j, double v,  int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E; i++) {
		if (shot_e[i].standby) {
			p_i[0] = 6, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color,p_i[6]=100000 , p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[3] = ang, p_d[4] = v, p_d[5] = 0, p_d[7] = 0, p_d[8] = 0,
			p_d[9] = ang_j, p_d[10] = damage, p_d[13] = ijou_damage,p_d[14]=0;
			shot_e[i].init(p_i, p_d);
			push(i, false);
			break;
		}
	}
}
void createshot05(double x, double y, double ang, double ang_a, double ang_j,  double v,  double a, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E; i++) {
		if (shot_e[i].standby) {
			p_i[0] = 6, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[6] = 100000, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[3] = ang_a, p_d[4] = v, p_d[5] = a, p_d[7] = 0, p_d[8] = 0,
			p_d[9] = ang_j, p_d[10] = damage, p_d[13] = ijou_damage, p_d[14] = 0;
			shot_e[i].init(p_i, p_d);
			push(i, false);
			break;
		}
	}
}
void createshot05(double x, double y, double ang, double ang_a, double ang_j, double v, double a,double mo,double mo_a,double mo_e, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E;i++) {
		if (shot_e[i].standby) {
			p_i[0] = 6, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[6] = 100000, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[3] = ang_a, p_d[4] = v, p_d[5] = a, p_d[7] = mo, p_d[8] = mo_e,
			p_d[9] = ang_j, p_d[10] = damage, p_d[13] = ijou_damage, p_d[14] = mo_a;
			shot_e[i].init(p_i, p_d);
			push(i, false);
			break;
		}
	}
}
void createshot05(double x, double y, double ang, double ang_j, double v, double mo, double mo_a, double mo_e, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E;i++) {
		if (shot_e[i].standby) {
			p_i[0] = 6, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[6] = 100000, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[3] = 0, p_d[4] = v, p_d[5] = 0, p_d[7] = mo, p_d[8] = mo_e,
				p_d[9] = ang_j, p_d[10] = damage, p_d[13] = ijou_damage, p_d[14] = mo_a;
			shot_e[i].init(p_i, p_d);
			push(i, false);
			break;
		}
	}
}
void createlaser01(double damage,double ijou_damage, int ijou_type, int pattern, double x, double y, double ang, double v, double l, int id_graph, int id_color, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < MaxShot_E;i++) {
		if (shot_e_add[i].standby) {
			p_i[0] = 4, p_i[1] = 0, p_i[2] = 1, p_i[3] = delay, p_i[4] = id_graph, p_i[5] = id_color, p_i[6] = false, p_i[7] = pattern, p_i[8] = ijou_type;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[3] = ang, p_d[4] = v, p_d[5] = false, p_d[6] = false, p_d[7] = false, p_d[8] = false,
				p_d[9] = false, p_d[11] = l, p_d[10] = damage, p_d[13] = ijou_damage;
			shot_e_add[i].init(p_i, p_d);
			push(i, true);
			break;
		}
	}
}
void createEnemy01(double x, double y, int hp, double type) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < Max_Enemy;i++) {
		if (zako[i].standby) {
			p_i[0] = type, p_i[1] = 0, p_i[2] = hp;
			p_d[0] = x, p_d[1] = y;
			zako[i].init(p_i, p_d);
			break;
		}
	}
}
void particle_delay(double x, double y, double ang, int id_graph, int id_color, int delay) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < Max_Particle; i++) {
		if (particle[i].standby) {
			p_i[0] = 1, p_i[1] = 0, p_i[2] = 1, p_i[6] = delay, p_i[4] = id_graph, p_i[5] = id_color;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[4] = 0, p_d[5] = 0;
			particle[i].init(p_i, p_d);
			break;
		}
	}
}
void particle_fadeout(double x, double y, double ang, int id_graph, int id_color, int time) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < Max_Particle;i++) {
		if (particle[i].standby) {
			p_i[0] = 2, p_i[1] = 0, p_i[2] = 1, p_i[6] = time, p_i[4] = id_graph, p_i[5] = id_color;
			p_d[0] = x, p_d[1] = y, p_d[2] = ang, p_d[4] = 0, p_d[5] = 0;
			particle[i].init(p_i, p_d);
			break;
		}
	}
}
void rupture01(double x, double y, double r, int id_color, int time) {
	int i = 0, p_i[15]; double p_d[15];
	for (; i < Max_Particle;i++) {
		if (particle[i].standby) {
			p_i[0] = 3, p_i[1] = 0, p_i[2] = 1, p_i[6] = time, p_i[4] = 0, p_i[5] = id_color;
			p_d[0] = x, p_d[1] = y, p_d[2] = 0, p_d[4] = 0, p_d[5] = 0, p_d[12] = r;
			particle[i].init(p_i, p_d);
			break;
		}
	}
}
