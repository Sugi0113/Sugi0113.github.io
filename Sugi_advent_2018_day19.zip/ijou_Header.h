#pragma once
#define PI acos(-1)
//��`(�E�C���h�E�A�g�̍��W)
#define GetMX 640
#define GetMY 480
#define GetCX GetMX/2
#define GetCY GetMY/2
#define GetmX_f 30
#define GetMX_f 430
#define GetmY_f 10
#define GetMY_f 470
#define GetCX_f (GetmX_f+GetMX_f)/2
#define GetCY_f (GetmY_f+GetMY_f)/2
//��`(�F)
#define White GetColor(255,255,255)
#define Black GetColor(0,0,0)
#define Red GetColor(255,0,0)
#define Green GetColor(0,255,0)
#define Blue GetColor(0,0,255)
#define Yellow GetColor(255,255,0)
#define Orange GetColor(255,165,0)
#define Niji_Green GetColor(0,128,0)
#define LightBlue GetColor(0,255,255)
#define purple GetColor(128,0,128)

//��`(�ő�)
#define M_shield 100
#define M_ijou_param 100
//�v���g�^�C�v�錾(ijou_function.cpp)
double AngToRad(double ang);
double RadToAng(double rad);
int DrawGraph2(int x, int y, int gh, int TransFlag);
void DrawBox2(double x, double y, double w, double h, int color);
double SecToFrame(double Sec);
double aPers(double apers);	
double rate(double current, double max);
double S_Triangle(double a, double b, double c);//�w�����̌�����p���āA�O�ӂ��炻�̎O�p�`�̖ʐς��Z�o
int isCollCirWithCir(double x1, double y1, double r1, double x2, double y2, double r2);
int is_create01(int interval);
int is_create02(int time_s, int time_e, int interval);
int is_create03(int interval, int devide, int interval_m);
//�v���g�^�C�v�錾(main.cpp)
void hidan();
void init_title();
void init_stg1();
void stg1();
void gpCalc();
void gpDraw();
//createshot01...�P�Ȃ铙�������^���̒e
void createshot01(double x, double y, double ang, double v, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
void createshot01_p(double x, double y, double ang, double v, int id_graph, int id_color, double damage ,int delay);
//createshot02...�������x�^���̒e�A�����ƈႤ�����ɉ����x��^���邱�Ƃ��ł���
void createshot02(double x, double y, double ang, double v, double a, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
void createshot02(double x, double y, double ang, double ang_a, double v, double a, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
//createshot03...�p���x�^���̒e�A�p�����x���t�^���邱�Ƃ��ł���]
void createshot03(double x, double y, double ang, double v, double mo, double mo_e, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
void createshot03(double x, double y, double ang, double v, double mo,double mo_a, double mo_e, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
//createshot04...�C�ӂ̎��Ԃ����Ə��ł���e
void createshot04(double x, double y, double ang, double v, int time, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
//createshot04_add...���[�U�[�̎c���p
void createshot04_add(double x, double y, double ang, double v, int time, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
//createshot05...�C�ӂ̕����ɓ��������̒e(���p�`�e�Ɏg�p)
void createshot05(double x, double y, double ang, double ang_j, double v, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
void createshot05(double x, double y, double ang, double ang_a, double ang_j, double v, double a, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
void createshot05(double x, double y, double ang, double ang_a, double ang_j, double v, double a, double mo, double mo_a, double mo_e, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
void createshot05(double x, double y, double ang, double ang_j, double v, double mo, double mo_a, double mo_e, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
//createshot1234...01,02,03,04�̕���ver
void createshot1234(double x, double y, double ang, double ang_a, double v, double a, double mo, double mo_a, double mo_e, int time, int id_graph, int id_color, double damage, double ijou_damage, int ijou_type, int delay);
//�����ւɂ�背�[�U�[
void createlaser01(double damage, double ijou_damage, int ijou_type, int pattern, double x, double y, double ang, double v, double l, int id_graph, int id_color, int delay);
//createPolygonShot01...�����x�̑��p�`�e
void createPolygonShot01(double k, double n, double x, double y, double ang, double v, int graph, int color, double damage, double ijou_damage, int ijou_type, int delay);
//createPolygonShot02...�����x�t�����p�`�e
void createPolygonShot02(double k, double n, double x, double y, double ang, double ang_a, double v, double a, int graph, int color, double damage, double ijou_damage, int ijou_type, int delay);
void createPolygonShot02(double k, double n, double x, double y, double ang, double v, double a, int graph, int color, double damage, double ijou_damage, int ijou_type, int delay);
//createPolygonShot02...�p���x�t�����p�`�e
void createPolygonShot03(double k, double n, double x, double y, double ang, double v, double mo, double mo_a, double mo_e, int graph, int color, double damage, double ijou_damage, int ijou_type, int delay);
void createEnemy01(double x, double y, int hp, double type);
void particle_delay(double x, double y, double ang, int id_graph, int id_color, int delay);
void particle_fadeout(double x, double y, double ang, int id_graph, int id_color, int time);
void rupture01(double x, double y, double r, int id_color, int time);
double offsetX(double r, double ang);
double offsetY(double r, double ang);

void push(int, bool add);
void erase(int, bool);
extern int CurrentShot_P;
extern int debug;
class GRAPHIC {
public:
	int wisp[9];
	
}__declspec(selectany)graphic;
class SYSTEM {
public:
	int difficulty, player, stage, count_all = 0, count_stg, pose = 0, is_PlayerKey = 1;//stage=0�̓^�C�g��,difficulty��0�`3
	void NextStage() {
		stage++;
		count_stg = 0;
	}
}__declspec(selectany)sys;
class BGM {
public:
	int stg[3];
}__declspec(selectany)bgm;
class SE {
public:
	int shot[5], vanish, select,shield_damage, shield_break,
		hidan, graze;
	void init() {
		shot[0] = LoadSoundMem("se/SE v0.20/shot1.wav");
		shot[1] = LoadSoundMem("se/SE v0.20/shot2.wav");
		select = LoadSoundMem("se/SE v0.20/SELECT.wav");
		vanish = LoadSoundMem("se/SE v0.20/enemy_vanish[�������o�[�u�̂�].wav");
		shield_break = LoadSoundMem("se/rabo/glass-break2.mp3");
		hidan= LoadSoundMem("se/nc899.wav");
		graze= LoadSoundMem("se/SE v0.20/graze.wav");
		shield_damage = LoadSoundMem("se/SE v0.20/enemy_damage.wav");
	}
}_declspec(selectany)se;
class TITLE {
public:
	int graph[11];//0.�^�C�g��,1.�X�^�[�g,2.�Q�[�����I����
	int choice, choice2,select=0;
	int count = 0;
	void calc() {
		if (CheckHitKey(KEY_INPUT_Z) && count == 0) {
			if (choice2 == 0) {
				switch (choice) {
				case 0:
					count++;
					break;
				case 1:
					DxLib_End();
					break;
				}
			}
			else if (choice2 == 1) {
				switch (choice) {
				case 0:
					sys.difficulty = 0;
					break;
				case 1:
					sys.difficulty = 1;	
					break;
				case 2:
					sys.difficulty = 2;
					break;
				case 3:
					sys.difficulty = 3;
					break;
				}
				count++;
			}
			else if (choice2 == 2) {
				switch (choice) {
				case 0:
					sys.player = 0;
					sys.NextStage();
					break;
				case 1:
					sys.player = 1;
					break;
				}
				count++;
			}
			choice = 0;
			choice2++;
		}
		if (CheckHitKey(KEY_INPUT_X) &&count%30==0) {
			if (choice2 > 0) {
				choice2--;
			}
			else if (choice2==0) {
				choice = 1;
			}

		}
		if (CheckHitKey(KEY_INPUT_UP) && count % 30 == 0) {
			switch (choice2) {
			case 0:
			case 2:
				if (choice == 0)
					choice = 1;
				else
					choice--;
				break;
			case 1:
				if (choice == 0)
					choice=3;
				else
					choice--;
				break;
			}
			PlaySoundMem(se.select, 1);
		}
		else if (CheckHitKey(KEY_INPUT_DOWN) && count % 30 == 0) {
			switch (choice2) {
			case 0:
			case 2:
				if (choice == 1)
					choice = 0;
				else
					choice++;
				break;
			case 1:
				if (choice == 3)
					choice = 0;
				else
					choice++;
				break;
			}
			PlaySoundMem(se.select, 1);
		}
		
		if(CheckHitKey(KEY_INPUT_UP)|| CheckHitKey(KEY_INPUT_DOWN)|| CheckHitKey(KEY_INPUT_Z)|| CheckHitKey(KEY_INPUT_X)){
			count++; 
		}
		else
			count = 0;
			
	}
	void draw() {
		DrawGraph2(GetCX, GetCY, graph[0], 1);
		if (choice2 == 0) {
			switch (choice) {
			case 0:
				SetDrawBright(255, 0, 0);
				DrawGraph2(230, GetCY, graph[1], 1);
				SetDrawBright(200, 0, 0);
				DrawGraph2(250, GetCY + 100, graph[2], 1);
				SetDrawBright(255, 255, 255);
				break;
			case 1:
				SetDrawBright(200, 0, 0);
				DrawGraph2(250, GetCY, graph[1], 1);
				SetDrawBright(255, 0, 0);
				DrawGraph2(230, GetCY + 100, graph[2], 1);
				SetDrawBright(255, 255, 255);
				break;
			}

		}			
		else if (choice2 == 1) {
			switch (choice) {
				case 0:
					SetDrawBright(255, 0, 0);
					DrawGraph2(230, GetCY, graph[4], 1);
					SetDrawBright(200, 0, 0);
					DrawGraph2(250, GetCY + 50, graph[5], 1);
					DrawGraph2(250, GetCY + 100, graph[6], 1);
					DrawGraph2(250, GetCY + 150, graph[7], 1);
					SetDrawBright(255, 255, 255);
					break;
				case 1:
					SetDrawBright(200, 0, 0);
					DrawGraph2(250, GetCY, graph[4], 1);
					SetDrawBright(255, 0, 0);
					DrawGraph2(230, GetCY + 50, graph[5], 1);
					SetDrawBright(200, 0, 0);
					DrawGraph2(250, GetCY + 100, graph[6], 1);
					DrawGraph2(250, GetCY + 150, graph[7], 1);
					SetDrawBright(255, 255, 255);
					break;
				case 2:
					SetDrawBright(200, 0, 0);
					DrawGraph2(250, GetCY, graph[4], 1);
					DrawGraph2(250, GetCY + 50, graph[5], 1);
					SetDrawBright(255, 0, 0);
					DrawGraph2(230, GetCY + 100, graph[6], 1);
					SetDrawBright(200, 0, 0);
					DrawGraph2(250, GetCY + 150, graph[7], 1);
					SetDrawBright(255, 255, 255);
					break;
				case 3:
					SetDrawBright(200, 0, 0);
					DrawGraph2(250, GetCY, graph[4], 1);
					DrawGraph2(250, GetCY + 50, graph[5], 1);
					DrawGraph2(250, GetCY + 100, graph[6], 1);
					SetDrawBright(255, 0, 0);
					DrawGraph2(230, GetCY + 150, graph[7], 1);
					SetDrawBright(255, 255, 255);
					break;
			}
			SetDrawBright(100, 50, 125);
			DrawGraph2(250, GetCY - 50, graph[3], 1);
			SetDrawBright(255, 255, 255);
		}
		else if (choice2 == 2) {
			switch (choice) {

			case 0:
				SetDrawBright(255, 0, 0);
				DrawGraph2(230, GetCY, graph[9], 1);
				SetDrawBright(200, 0, 0);
				DrawGraph2(250, GetCY + 50, graph[10], 1);
				SetDrawBright(255, 255, 255);
				break;
			case 1:
				SetDrawBright(200, 0, 0);
				DrawGraph2(250, GetCY, graph[9], 1);
				SetDrawBright(255, 0, 0);
				DrawGraph2(230, GetCY + 50, graph[10], 1);
				SetDrawBright(255, 255, 255);
				break;
			}
			SetDrawBright(100, 50, 125);
			DrawGraph2(250, GetCY - 50, graph[8], 1);
			SetDrawBright(255, 255, 255);
		}
	}
}__declspec(selectany)title;
class POSE{
public:
	void calc() {

	}
	void draw() {
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
		DrawBox2(GetCX_f, GetCY_f, 400, 500, Red);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
	}
}__declspec(selectany)pose;
class STAGE {
public:
	int graph[4],frame;
}__declspec(selectany)stg;
class OBJECT {
public:
	int graph;
	double x, y;
};
class SHOT_TYPE {
public:
	int graph[20];
	double r;
	char name[10];
	int GetGraph(int id_gp) {
		if (id_gp >= 20)
			return -1;
		else
			return graph[id_gp];
	}
	double GetR(int id_gp) {
		switch (id_gp) {
		case 0:
			return 6.0;
			break;
		case 1:
			return 2.0;
			break;
		case 2:
			return 4.0;
			break;
		case 3:
			return 7.0;
			break;
		case 4:
			return 4.0;
			break;
		case 5:
			return 2.0;
			break;
		default:
			return -1.0;
			break;
		}

	}
	void SetColor(int id_color) {
		switch (id_color) {
		case 0:
			SetDrawBright(255, 255, 255);//�V��
			break;
		case 1:
			SetDrawBright(255, 0, 0);//�A�J
			break;
		case 2:
			SetDrawBright(255, 165, 0);//�I�����W
			break;
		case 3:
			SetDrawBright(255, 255, 0);//�L�C��
			break;
		case 4:
			SetDrawBright(0, 128, 0);//�~�h��(��)
			break;
		case 5:
			SetDrawBright(0, 255, 255);//�~�Y�C��
			break;
		case 6:
			SetDrawBright(0, 0, 255);//�A�I
			break;
		case 7:
			SetDrawBright(128, 0, 128);//�����T�L(��)
			break;
		case 8:
			SetDrawBright(0, 0, 0);//�N��
			break;
		default:
			break;
		}
	}

}__declspec(selectany)s_typ;
class E_Shot :public OBJECT {
public:
	int count = 0, is_graze = 0, is_ijou = 0, ijou_type = 0; double mo_count = 0, vk = 0;
	int mode = 1,ptn=0, exist = 0, standby = 1, delay = 0, id_graph = 0, id_color = 0, time = 0;
	double v = 0, vx = 0, vy = 0, ve = 0, a = 0, ax = 0, ay = 0, ang, ang_a, r = ang, mo = 0, mo_a = 0 , mo_e = 0,
		ang_j = 0, l, damage,ijou_damage;
	
	void move_e(int erase_index, bool add) {
		if (x <= -100 || x >= GetMX || y >= GetMY + 100 || y <= -100) {
			vanish_e(10, erase_index, add);
		}
		if (exist &&delay == 0) {

			switch (mode) {
			case 6:
			case 1://�C�ӂ̕����ɉ����x��^����
			case 5://1,2,3�̕���
				ax = a * cos(AngToRad(ang_a));
				ay = a * sin(AngToRad(ang_a));
				vx += ax;
				vy += ay;
				if (mode == 1) {
					break;
				}
			case 2://�p���x�A�p�����x��^����
				ang = RadToAng(atan2(vy, vx));
				if (v < 0) {
					ang += 180;
				}
				v = hypot(vy, vx);

				if (mo_e > mo_count) {
					mo += mo_a;
					ang += mo;
					mo_count += fabs(mo);
				}
				vx = v * cos(AngToRad(ang));
				vy = v * sin(AngToRad(ang));
				if (mode != 5 && mode != 6) {
					break;
				}
			case 3:	//��莞�Ԃŏ�����e
				if (time-- == 0) {
					vanish_e(10, erase_index, add);
				}

				break;
			case 4://���[�U�[(�v�e�o�^)
				//���������Ƀ��[�U�[�̋O�����L�q
				switch (ptn) {
				case 1:
					if (count < 60)
						ang += 2;
					else if (count < 120)
						ang -= 5;
					else if (count < 180)
						ang += 1;
					else if (count < 240)
						ang -= 1;
					else if (count < 300)
						ang += 4;
					break;
				case 2:
					if (count % 30 < 15)
						ang += 4;
					else
						ang -= 4;
					break;
				}
				createshot04_add(x, y, ang, 0, l / v, id_graph, id_color, damage, ijou_damage, ijou_type, 0);
				break;
			}
			x += vx;
			y += vy;
		}
		count++;
		if (delay > 0)
			delay--;

	}
	void move_p() {
		if (x <= -100 || x >= GetMX || y >= GetMY + 100 || y <= -100) {
			vanish_p(10);
		}
		if (exist &&delay == 0) {

			switch (mode) {
			case 6:
			case 1://�C�ӂ̕����ɉ����x��^����
			case 5://1,2,3�̕���
				ax = a * cos(AngToRad(ang_a));
				ay = a * sin(AngToRad(ang_a));
				vx += ax;
				vy += ay;
				if (mode == 1) {
					break;
				}
			case 2://�p���x�A�p�����x��^����
				ang = RadToAng(atan2(vy, vx));
				if (v < 0) {
					ang += 180;
				}
				v = hypot(vy, vx);

				if (mo_e > mo_count) {
					mo += mo_a;
					ang += mo;
					mo_count += fabs(mo);
				}
				vx = v * cos(AngToRad(ang));
				vy = v * sin(AngToRad(ang));
				if (mode != 5 && mode != 6) {
					break;
				}
			case 3:	//��莞�Ԃŏ�����e
				if (time-- == 0) {
					vanish_p(30);
				}

				break;
			case 4://���[�U�[(�v�e�o�^)
				//���������Ƀ��[�U�[�̋O�����L�q
				switch (ptn) {
				case 1:
					if (count < 60)
						ang += 2;
					else if (count < 120)
						ang -= 5;
					else if (count < 180)
						ang += 1;
					else if (count < 240)
						ang -= 1;
					else if (count < 300)
						ang += 4;
					break;
				case 2:
					if (count % 30 < 15)
						ang += 4;
					else
						ang -= 4;
					break;
				}
				createshot04_add(x, y, ang, 0, l / v, id_graph, id_color, damage, ijou_damage, ijou_type, 0);
				break;
			}
			x += vx;
			y += vy;
		}
		count++;
		if (delay > 0)
			delay--;

	}
	void draw() {
		s_typ.SetColor(id_color);
		DrawRotaGraph(x, y, 1, AngToRad(ang + 90), graph, 1);
		s_typ.SetColor(0);
	}
	void init(int p_i[],double p_d[]) {
		mode = p_i[0], ptn = p_i[7], standby = p_i[1], exist = p_i[2], delay = p_i[3], id_graph = p_i[4], id_color = p_i[5], time = p_i[6], ijou_type = p_i[8];
		x = p_d[0], y = p_d[1], ang = p_d[2], ang_a = p_d[3], v = p_d[4], a = p_d[5];
		ax = a * cos(AngToRad(ang)), ay = a * sin(AngToRad(ang)), ve = p_d[6], mo = p_d[7];
		mo_e = p_d[8]; ang_j = p_d[9],damage=p_d[10], l = p_d[11],ijou_damage=p_d[13], mo_a = p_d[14], mo_count = 0;
		graph = s_typ.GetGraph(id_graph), r = s_typ.GetR(id_graph), count = 0;
		if (mode != 6) {
			vx = v * cos(AngToRad(ang)); vy = v * sin(AngToRad(ang));
		}
		else if (mode == 6) {
			vx = v * cos(AngToRad(ang_j));
			vy = v * sin(AngToRad(ang_j));
			ax = a * cos(AngToRad(ang_j));
			ay = a * sin(AngToRad(ang_j));
			v = hypot(v, (vx*tan(AngToRad(ang)) - vy) / (sin(AngToRad(ang_j + 90)) - tan(AngToRad(ang))*cos(AngToRad(ang_j + 90))));
			if (v < 0 && a>=0) {
				ang -= 180;
			}
			else if (v >= 0 && a < 0) {
				ang += 180;
			}
			a = hypot(a, (ax*tan(AngToRad(ang)) - ay) / (sin(AngToRad(ang_j + 90)) - tan(AngToRad(ang))*cos(AngToRad(ang_j + 90))));
			vx = v * cos(AngToRad(ang));
			vy = v * sin(AngToRad(ang));
			ax = a * cos(AngToRad(ang));
			ay = a * sin(AngToRad(ang));
		}

		is_graze = 0;
		if (delay > 0)
			particle_delay(x, y, ang, id_graph, id_color, delay);
	}
	void vanish_e(int t_fadeout, int rank, bool add) {
		debug = t_fadeout;
		erase(rank, add);
		exist = 0; standby = 1;
		particle_fadeout(x, y, ang, id_graph, id_color, t_fadeout);
	}
	void vanish_p(int t_fadeout) {
		CurrentShot_P--;
		exist = 0; standby = 1;
		particle_fadeout(x, y, ang, id_graph, id_color, t_fadeout);
	}
};
class Particle:public OBJECT {
	public:
		double alpha = 255, ang, v, r, r0;
		int mode = 0, standby = 1, exist = 0, state = 0, count = 0,fade_timer=0, time_fade = 0, exist_time = 1, exist_timer = 1 , delay = 0,
			id_graph, id_color;
		void move() {
			if (mode == 1) {
				r -= 2*s_typ.GetR(id_graph) / exist_time;
			}
			else if (mode == 2) {
				r -=  s_typ.GetR(id_graph) / exist_time;
			}
			else if (mode == 3) {
				r += r0/exist_time;
			}
			if (state == 1) {
				static int fadeout_timer = 0;
				alpha_add(-255.0 / time_fade);
				if (fadeout_timer == time_fade) {
					
					fadeout_timer = 0;
					state = 0;
				}
				fadeout_timer++;
			}
			else if (state == 2) {
				alpha_add(255.0 / time_fade);
				if (fade_timer == time_fade) {
					fade_timer = 0;
					state = 0;
				}
				fade_timer++;
			}
			if (exist_timer == 0)
				vanish();
			exist_timer--;
			count++;
		}
		void draw() {	
			SetDrawBlendMode(DX_BLENDMODE_ALPHA, (int)alpha);
			s_typ.SetColor(id_color);
			if (mode == 3) {
				DrawCircle(x, y, r, White, 0, 10);
			}
			else
				DrawRotaGraph(x, y, r/s_typ.GetR(id_graph), AngToRad(ang+90), graph, 1);
			s_typ.SetColor(0);
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
		}
		void init(int p_i[],double p_d[]) {
			mode = p_i[0],standby=p_i[1],exist=p_i[2],id_graph=p_i[4],id_color=p_i[5],exist_time = p_i[6];
			x = p_d[0], y = p_d[1], ang = p_d[2], v = p_d[4];
			graph = s_typ.GetGraph(id_graph), r = s_typ.GetR(id_graph);
			count = 0, exist_timer = exist_time, alpha_add(255),state=0;
			if (mode == 1) {
				r *= 3;
				alpha_add(-255);
				fadein(exist_time);
			
			}
			else if (mode == 2) {
				alpha_add(255);
				fadeout(exist_time);
			}
			else if (mode == 3) {
				r0 = p_d[12];
				r = 0;
			}
		}
		void alpha_add(double param) {
			alpha += param;
			if (alpha > 255) {
				alpha = 255;
			}
			else if (alpha < 0) {
				alpha = 0;
			}
		}
		void fadeout(int t) {
			time_fade = t;
			fade_timer = 0;
			state = 1;
		}
		void fadein(int t) {
			time_fade = t;
			fade_timer = 0;
			state = 2;
		}
		void vanish() {
			exist = 0, standby = 1;
		}
};
class Player :public OBJECT {
public:
	int hp = 2, bom = 3;
	int graph[3], width = 25, invincible, time_invincible, count = 0, is_hidan = 0;
	double v, shield = M_shield, r, ijou_param[5] = {}, is_ijou[5] = {};
	void hp_add(int i) {
		if (hp <= 9)
			hp += i;
		if (hp > 9)
			hp = 9;
		else if (hp < 0) {
			hp = -1;
		}
	}
	void bom_add(int i) {
		if (bom <= 9)
			bom += i;
		if (bom > 9)
			bom = 9;
		else if (bom < 0)
			bom = 0;
		
	}
	void shield_add(double r) {
		if (shield <= M_shield)
			shield += r;
		if (shield > M_shield)
			shield = M_shield;
		else if (shield < 0)
			shield = 0;
	}
	void ijou_param_add(int type, double r) {
		if (ijou_param[type] <= M_ijou_param)
			ijou_param[type] += r;
		if (ijou_param[type] > M_ijou_param)
			ijou_param[type] = M_ijou_param;
		else if (ijou_param[type] < 0)
			ijou_param[type] = 0;
	}
	void init() {
		x = GetCX_f, y = GetCY_f + 200, v = 3, r = 2;
		graph[0] = LoadGraph("graphic/player/player_test.png", 1);
		graph[1] = LoadGraph("graphic/player/atari.png", 1);
		graph[2] = LoadGraph("graphic/player/atari_pointer.png", 1);
	}
	void move() {
		if (sys.is_PlayerKey == 1) {
			if (CheckHitKey(KEY_INPUT_RIGHT) && (x + width / 2) < GetMX_f) {
				if (CheckHitKey(KEY_INPUT_LSHIFT))
					x += v / 4;
				else
					x += v;
			}
			if (CheckHitKey(KEY_INPUT_LEFT) && (x - width / 2) > GetmX_f) {
				if (CheckHitKey(KEY_INPUT_LSHIFT))
					x -= v / 4;
				else
					x -= v;
			}
			if (CheckHitKey(KEY_INPUT_DOWN) && (y + width / 2) < GetMY_f) {
				if (CheckHitKey(KEY_INPUT_LSHIFT))
					y += v / 4;
				else
					y += v;
			}
			if (CheckHitKey(KEY_INPUT_UP) && (y - width / 2) > GetmY_f) {
				if (CheckHitKey(KEY_INPUT_LSHIFT))
					y -= v / 4;
				else
					y -= v;
			}
			if (CheckHitKey(KEY_INPUT_Z)) {
				static int count = 0;
				if (CheckHitKey(KEY_INPUT_LSHIFT)) {
					if (count % 5 == 4) {
						static double angle = 90; static int flag = 0;
						if (flag == 0)
							angle += 5;
						else if (flag == 1)
							angle -= 5;
						if (angle >= 100)
							flag = 1;
						else if (angle <= 80)
							flag = 0;
						
					}
					if (count % 3 == 2) {
						createshot01_p(x, y, 90, 3, 0, 0, 3, 0);
					}
				}
				else {
					if (count % 5 == 4) {
						static double angle = 90; static int flag = 0;
						if (flag == 0)
							angle += 5;
						else if (flag == 1)
							angle -= 5;
						if (angle >= 100)
							flag = 1;
						else if (angle <= 80)
							flag = 0;
						


					}
					if (count % 3 == 2) {
						
					}
				}
				count++;
			}
		}
		if (is_hidan == 1) {
			static int hidan_time = 0;
			if (hidan_time == 0)
				x = GetCX_f, y = GetMY_f + 60;
			if (hidan_time < 100)
				y -= 1;
			hidan_time++;
			if (hidan_time == 100)
				is_hidan = 0, hidan_time = 0, sys.is_PlayerKey = 1;
		}
		if (invincible == 1) {
			static int invin_timer = 0;
			invin_timer++;
			if (invin_timer == time_invincible) {
				invin_timer = 0;
				invincible = 0;
			}
		}
		else if (is_ijou[0] == 1)//�ŏ��(���G�͏���)�̎��̏���
			shield_add(-0.1);

		count++;
	}
	void draw() {
		static double angle = 0;
		if (is_hidan == 1 &&count%3==0) {
			s_typ.SetColor(1);
		}
		if (invincible == 1) {
			if (count % 4) {
				DrawGraph2(x, y, graph[0], 1);
			}
		}else
			DrawGraph2(x, y, graph[0], 1);
		if (CheckHitKey(KEY_INPUT_LSHIFT)) {
			DrawGraph2(x, y, graph[1], 1);
			DrawRotaGraph(x, y, 0.5, AngToRad(angle), graph[2], 1);
			angle++;
		}
		s_typ.SetColor(0);
	}
	void set_invincible(int time) {
		invincible = 1;
		time_invincible = time;
	}
}__declspec(selectany)player;
class R_UI :public OBJECT{
public:
	int text[3];
	int ico[10];
	int num;
	void set_i(int i) {
		switch (i) {
		case 0:
			
			break;
		}
	}
	void calc() {
		//�c�@�̌v�Z
		//��Ԉُ�̏���(�Q�[�W)
		for (int i=0; i < 5; i++) {
			if (player.ijou_param[i] == M_ijou_param)
				player.is_ijou[i] = 1;
			else if (player.ijou_param[i] == 0 )
				player.is_ijou[i] = 0;
			if (player.is_ijou[i] == 1)
				player.ijou_param_add(i, -0.1);
		}
		
	}
	void draw() {
		int i;
		x = GetMX_f+120,y=GetmY_f+20;
		SetDrawBright(255, 0, 255);
		DrawRotaGraph(x, y, 0.4, AngToRad(0), text[0], 1);
		DrawRotaGraph(x+10, y+40, 0.4, AngToRad(0), text[1], 1);
		DrawRotaGraph(x + 20, y + 130, 0.4, AngToRad(0), text[2], 1);
		SetDrawBright(255, 255, 255);
		for (i = 0; i < player.hp; i++) {
			DrawRotaGraph(x-100 + 22*i, y + 20,0.5,0, ico[0], 1);
		}
		for (i = 0; i < player.bom; i++) {
			DrawRotaGraph(x - 100 + 22 * i, y + 60, 0.5, 0, ico[1], 1);
		}
		DrawRotaGraph(x - 100, y + 100, 0.6, 0, ico[7], 1);
		DrawLine(x - 70, y + 100, x +30, y + 100, GetColor(0, 0,0), 10);
		DrawLine(x -70, y + 100, x - 70 + rate(player.shield, M_shield), y + 100, GetColor(255, 255,rate(player.shield, M_shield)), 10);
		for (int i = 0; i < 5; i++) {
			DrawLine(x - 70, y + 150+30*i, x + 30, y + 150 + 30 * i, GetColor(0, 0, 0), 10);
			DrawLine(x - 70, y + 150+30*i, x - 70 + rate(player.ijou_param[i], M_ijou_param), y + 150 + 30 * i, GetColor(255, 255, 255), 10);
		}
		DrawRotaGraph(x - 100, y + 150, 0.5, 0, ico[3], 1);
		DrawRotaGraph(x - 100, y + 180, 0.5, 0, ico[2], 1);
		DrawRotaGraph(x - 100, y + 210, 0.5, 0, ico[4], 1);
		DrawRotaGraph(x - 100, y + 240, 0.5, 0, ico[5], 1);
		DrawRotaGraph(x - 100, y + 270, 0.5, 0, ico[6], 1);
	}
	
}__declspec(selectany)UI_r;
class Zako :public OBJECT {
public:
	int standby=1, exist = 0,change = 0;
	int hp = 10, graph[10], type, type_e, count = 0;
	double ang = 0, v = 0, vx = 0, vy = 0, a = 0, ax = 0, ay = 0,r=10;
	void move() {
		if (count % 5 == 0) {
			change++;
			if (change >= 3) {
				change = 0;
			}
			
		}
		if (hp <= 0) {
			PlaySoundMem(se.vanish, 1);
			rupture01(x, y, 30, 0, 30);
			vanish(10);
		}
		switch (type) {
		case 0:
			if (count == 0) {
				v = 12, a = -0.2; ang = -90, vx = v * cos(AngToRad(ang)), vy = v * sin(AngToRad(ang)),
					ax = a * cos(AngToRad(ang)), ay = a * sin(AngToRad(ang));
			}
			if (count==60 && sys.difficulty!=0) {
				PlaySoundMem(se.shot[0], 1);
				if (sys.difficulty == 1)
					createPolygonShot01(3, 10, x, y, GetRand(360), 1, 4, 5, 5, 0, 0, 10);
				else if (sys.difficulty == 2)
					createPolygonShot01(4, 10, x, y, GetRand(360), 1, 4, 5, 5, 0, 0, 10);
				else if (sys.difficulty == 3) {
					static double ang_r = (double)GetRand(360);
					createPolygonShot02(3, 10, x, y, ang_r+180, 1,-aPers(1), 0, 5, 5, 0, 0, 10);
					ang_r = (double)GetRand(360);
				}
			}
			if (count == 120) {
				end();
			}
			break;
		case 1:
			if (count == 0) {
				v = 2, a = 0; ang = -90, vx = v * cos(AngToRad(ang)), vy = v * sin(AngToRad(ang)),
					ax = a * cos(AngToRad(ang)), ay = a * sin(AngToRad(ang));
			}
			if (count %20== 0) {
				
				if (sys.difficulty == 0 &&count %60==0) {
					createshot01(5, 0, 0, x, y, -45, 1, 0, 0, 30);
					createshot01(5, 0, 0, x, y, -135, 1, 0, 0, 30);
					PlaySoundMem(se.shot[0], 1);
				}
				else if (sys.difficulty == 1 && count % 60 == 0) {
					createshot01(5, 0, 0, x, y, -45, 3, 0, 0, 30);
					createshot01(5, 0, 0, x, y, -135, 3, 0, 0, 30);
					PlaySoundMem(se.shot[0], 1);
				}
				else if (sys.difficulty == 2){
					createshot01(5, 0, 0, x, y, -45, 2, 0, 0, 30);
					createshot01(5, 0, 0, x, y, -135, 2, 0, 0, 30);
					PlaySoundMem(se.shot[0], 1);
				}
				else if (sys.difficulty == 3) {
					createshot01(5, 0, 0, x, y, -45, 3, 0, 0, 30);
					createshot01(5, 0, 0, x, y, -135, 3, 0, 0, 30);
					PlaySoundMem(se.shot[0], 1);
				}
				
			}
			if (count == 300) {
				end();
			}
			break;
		}
		vx += ax, vy += ay;
		x += vx, y += vy;
		count++;
	}
	void draw() {

		if (vx > 0){
			DrawGraph2(x, y, graph[change], 1);
	}
		else if (vx == 0) {
			DrawGraph2(x, y, graph[change + 3], 1);
		}
		else {
			DrawGraph2(x, y, graph[change + 6], 1);
			
		}
	}
	void init(int p_i[], double p_d[]) {
		exist = 1, standby = 0;
		type = p_i[0], type_e = p_i[1], hp = p_i[2];
		x = p_d[0], y = p_d[1]; 
		count = 0, change = 0;
		if (type_e == 0) {
			LoadDivGraph("graphic/enemy/enemy01.png", 9, 3, 3, 50, 50, graph);
		}
	}
	void end() {
		standby = 1, exist = 0;
	}
	void vanish(int time) {
		standby = 1, exist = 0;
	}
};
class Background {
public:
	int floor[3];
}_declspec(selectany)back;